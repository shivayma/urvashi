var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","dad0601e-7937-4b61-a524-b5b2965cb042","61088a64-2844-4a85-b7d1-a3921e81df42","dd59ac7d-e70d-415c-bde4-b094837c213d","f2eae118-e755-41fe-b935-bdb30dce631f","5db44f21-8718-4237-bff3-1a58cdf8a3e7"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"X8NiRW9mL_b26fybVoYQY5qeGIgRS4CL","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"pA05YIUUJaH5zgmR1FCr7a9dLKjsK5R2","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"rmc15xGbrT7duIL21Iq_LVq83jLQWSQq","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"dad0601e-7937-4b61-a524-b5b2965cb042":{"name":"rainbow","sourceUrl":"assets/api/v1/animation-library/gamelab/2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25./category_backgrounds/background_rainbow.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25.","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25./category_backgrounds/background_rainbow.png"},"61088a64-2844-4a85-b7d1-a3921e81df42":{"name":"donut","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"iGSLHN6xl6Tjx3oxeL6FS3l7X3HOtW8c","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/61088a64-2844-4a85-b7d1-a3921e81df42.png"},"dd59ac7d-e70d-415c-bde4-b094837c213d":{"name":"boy","sourceUrl":null,"frameSize":{"x":90,"y":90},"frameCount":1,"looping":true,"frameDelay":12,"version":"BykhgHrmhV8Lyo3tLQ1gPjDqPCfczCmY","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":90},"rootRelativePath":"assets/dd59ac7d-e70d-415c-bde4-b094837c213d.png"},"f2eae118-e755-41fe-b935-bdb30dce631f":{"name":"bear","sourceUrl":null,"frameSize":{"x":90,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"ar9c9Po20ZpzaGxzkZa5OSltwIfaPF9L","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":80},"rootRelativePath":"assets/f2eae118-e755-41fe-b935-bdb30dce631f.png"},"5db44f21-8718-4237-bff3-1a58cdf8a3e7":{"name":"rabbit","sourceUrl":null,"frameSize":{"x":90,"y":90},"frameCount":1,"looping":true,"frameDelay":12,"version":"bK9.yZ5FOY_Vdp9ihCDdljMqHln79uaR","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":90},"rootRelativePath":"assets/5db44f21-8718-4237-bff3-1a58cdf8a3e7.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var rainbow = createSprite(200,200);
rainbow.setAnimation("rainbow");

var donut = createSprite(350,50);
donut.setAnimation("donut");

var boy = createSprite(200,350);
boy.setAnimation("boy");

var bear = createSprite(50,140);
bear.setAnimation("bear");

var rabbit = createSprite(350,240);
rabbit.setAnimation("rabbit");

var goal = 0;
var death = 0;

rabbit.setVelocity(-10,0);
bear.setVelocity(10,0);



function draw() {
  createEdgeSprites();
  
  bear.bounceOff(edges);
  rabbit.bounceOff(edges);
  
  
  if (keyDown(UP_ARROW)){
    boy.y = boy.y-3;
  }
  
  if (keyDown(DOWN_ARROW)){
    boy.y = boy.y+3;
  }
  
  if (keyDown(LEFT_ARROW)){
    boy.x = boy.x-3;
  }
  
  if (keyDown(RIGHT_ARROW)){
    boy.x = boy.x+3;
  }
  
  if (boy.isTouching(rabbit) || boy.isTouching(bear)){
    playSound("assets/category_achievements/melodic_win_1.mp3")
    boy.x=200;
    boy.y=350;
    death=death+1;
  }
  
  if (boy.isTouching(donut)){
  playSound("assets/category_achievements/vibrant_game_postive_achievement_2.mp3")
  boy.x=200;
  boy.y=345;
  }
  textSize(20);
  fill("blue");
  text("Goals:"+goal,320,350);
  
  textSize(20);
  fill("blue");
  text("death:"+death,20,350);
  
  
  
drawSprites()}














// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
